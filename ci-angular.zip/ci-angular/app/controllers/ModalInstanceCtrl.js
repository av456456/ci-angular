app.controller('ModalInstanceCtrl', ['$scope', '$uibModalInstance', 'modalData', 'dataFactory', function ($scope, $uibModalInstance, modalData, dataFactory) {
        $scope.type = modalData.type;
        $scope.data = [];
        var type = modalData.type;
        if (type == 'subcategory')
        {
            var catId = modalData.catId;
            $scope.catId = catId;
            $scope.pageNumberModal = 1;
            var limit = 2;
            $scope.limitModal = limit;
            $scope.libraryTemp = {};
            $scope.totalItemsTemp = {};
            $scope.searchValueModal = "";
            $scope.totalItemsModal = 0;
            var page = 1;
            var searchValue = '';
            getSubCats(catId, page, searchValue, limit);
            $scope.pageChanged2 = function (newPage) {
                getSubCats($scope.catId, newPage, '', limit);
            };
            $scope.reset = function ()
            {
                $scope.subcatform = {id: '', catId: $scope.catId, name: ''};
            }
            $scope.reset();

            function getSubCats(catId, page, searchValue, limit)
            {
                var postParam = {
                    catId: catId,
                    page: page,
                    limit: limit,
                    searchValue: searchValue
                }
//                console.log(postParam);

                dataFactory.httpRequest('/items/subCategorys', 'POST', '', postParam).then(function (response) {
                    $scope.dataModal = response.dataList;
                    $scope.totalItemsModal = response.total;
                    $scope.pageNumberModal = postParam.page;
                });
            }



            $scope.subvalidationOptions = {
                rules: {
                    name: {
                        required: true,
                        minlength: 5
                    }
                },
                messages: {
                    name: {
                        required: "Please enter sub category",
                        minlength: "This input must have a minimum length of 6 characters"
                    }
                }
            }
            $scope.addEditSub = function (form)
            {
                if (form.validate())
                {
                    var postData = $scope.subcatform;
                    console.log(form);
                    dataFactory.httpRequest('/items/addEditSubCategory', 'POST', {}, postData).then(function (data) {
                        getSubCats($scope.catId, 1, '', $scope.limitModal);
                        $scope.reset();
                    });

                }
            }

            $scope.editSubCat = function (id)
            {
                var postData = {'id': id};
                console.log(postData);
                dataFactory.httpRequest('/items/getSubCat', 'POST', {}, postData).then(function (data) {
                    $scope.subcatform = data;
                });
            }
            $scope.deleteSubCat = function (id)
            {
                var postData = {'id': id};
                console.log(postData);
                var result = confirm("Are you sure delete this item?");
                if (result) {
                    dataFactory.httpRequest('/items/deleteSubCat', 'POST', {}, postData).then(function (data) {
                        getSubCats($scope.catId, 1, '', $scope.limitModal);

                    });
                }
            }

        }
        $scope.ok = function () {
            $uibModalInstance.close($scope.selected.item);
        };

        $scope.cancel = function () {
            $uibModalInstance.dismiss('cancel');
        };
    }]);