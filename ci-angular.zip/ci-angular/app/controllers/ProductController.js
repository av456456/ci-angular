
app.controller('ProductController', function ($scope, $routeParams, $http, $location, $uibModal, dataFactory) {
    $scope.data = [];
    $scope.pageNumber = 1;
    var limit = 2;
    $scope.limit = limit;

    $scope.libraryTemp = {};
    $scope.totalItemsTemp = {};
    $scope.searchValue = "";
    $scope.totalItems = 0;
    var page = 1;
    var searchValue = '';
    getList(page, searchValue, limit);
    $scope.pageChanged = function (newPage) {
        getList(newPage, '', limit);
    };

    function getList(page, searchValue, limit)
    {
        var postParam = {
            page: page,
            limit: limit,
            searchValue: searchValue
        }
        dataFactory.httpRequest('/product', 'POST', '', postParam).then(function (response) {
            $scope.data = response.dataList;
            $scope.totalItems = response.total;
            $scope.pageNumber = postParam.page;
        });
    }



    $scope.validationOptions = {
        rules: {
            name: {
                required: true,
                minlength: 5
            }
        },
        messages: {
            name: {
                required: "Please enter category",
                minlength: "This input must have a minimum length of 6 characters"
            }
        }
    }
    $scope.addEdit = function (form)
    {
        console.log($scope);
        //if (form.validate())
        {

            var postData = $scope.form;
            postData.image = $scope.myFile;
            $http({
                method: 'POST',
                url: '/ci-angular/product/addEditProduct',
                headers: {
                    'Content-Type': undefined
                },
                data: postData,
                transformRequest: function (data, headersGetter) {
                    var formData = new FormData();
                    angular.forEach(data, function (value, key) {
                        formData.append(key, value);
                    });

                    var headers = headersGetter();
                    delete headers['Content-Type'];

                    return formData;
                }
            })
                    .success(function (data) {

                    })
                    .error(function (data, status) {

                    });
//            dataFactory.httpRequest('/product/addEditProduct', 'POST', {}, postData,$scope.myFile).then(function (data) {
//                getList(1, '', $scope.limit);
//            });

        }
    }

    $scope.edit = function (id)
    {
        var postData = {'id': id};
        console.log(postData);
        dataFactory.httpRequest('/product/getCat', 'POST', {}, postData).then(function (data) {
            $scope.form = data;
        });
    }
    $scope.delete = function (id)
    {
        var postData = {'id': id};
        console.log(postData);
        var result = confirm("Are you sure delete this item?");
        if (result) {
            dataFactory.httpRequest('/product/deleteCat', 'POST', {}, postData).then(function (data) {
                getList(1, '', $scope.limit);

            });
        }
    }
    getCats();
    function getCats()
    {
        var postParam = {};
        dataFactory.httpRequest('/product/getCategory', 'POST', '', postParam).then(function (response) {
            $scope.categorys = response;
        });
    }

    $scope.getSubCats = function ()
    {
        var postParam = {
            catId: $scope.form.catId
        };
        dataFactory.httpRequest('/product/getSubCategory', 'POST', '', postParam).then(function (response) {
            $scope.subCategorys = response;
        });
    }

    $scope.searchDB = function ()
    {
        getList(1, $scope.searchValue, $scope.limit);
    }
    $scope.modalData = {};
    $scope.animationsEnabled = true;

    $scope.open = function (catId, size) {

        var modalInstance = $uibModal.open({
            animation: $scope.animationsEnabled,
            ariaLabelledBy: 'modal-title',
            ariaDescribedBy: 'modal-body',
            templateUrl: 'templates/subCategoryModal.html',
            controller: 'ModalInstanceCtrl',
            controllerAs: '$scope',
            size: size,
            resolve: {
                modalData: function () {
                    $scope.modalData.type = 'subcategory';
                    $scope.modalData.catId = catId;
                    return $scope.modalData;
                }
            }
        });


    };
});


