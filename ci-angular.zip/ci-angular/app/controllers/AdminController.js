app.controller('AdminController', function($scope,$routeParams,$location,dataFactory){
 
  $scope.pools = [];
  $scope.logOut=function()
  {
      dataFactory.httpRequest('/auth/logout','POST').then(function(response)
      {
          $location.path('/login');
      });
  }
});
