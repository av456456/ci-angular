
app.controller('LoginController', function ($scope, $rootScope, $routeParams, $timeout, $location, dataFactory) {
    $scope.data = [];
    $scope.login = {
        username: '',
        password: ''
    };
    $scope.loading = false;
    $scope.alerts = [];
    $scope.btLogin = 'Log In';
    $scope.validationOptions = {
        rules: {
            username: {
                required: true
            },
            password: {
                required: true,
                minlength: 5
            }
        },
        messages: {
            username: {
                required: "Please enter username"
            },
            password: {
                required: "You must enter a password",
                minlength: "Your password must have a minimum length of 6 characters"
            }
        }
    }
    $scope.submitLogin = function (form)
    {
        if (form.validate())
        {

            $scope.loading = true;
            $scope.btLogin = 'loading...';
            try {
                dataFactory.httpRequest('/admin/auth/login', 'POST', {}, $scope.login).then(function (data) {
                    if (data.status != 200)
                    {
                        $scope.loading = false;
                        alert(data.message);
                    } else {
                        $timeout(function () {
                            $location.path('/');
                        }, 1000);

                    }


                    console.log(data);
                });
            } catch (ex)
            {
                console.log(ex);
            }
        }

    }
});

