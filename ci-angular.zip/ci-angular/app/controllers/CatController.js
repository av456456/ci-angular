app.controller('CatController', function ($scope, $routeParams, $http, $location,$uibModal,dataFactory) {
    $scope.data = [];
    $scope.pageNumber = 1;
    var limit = 2;
    $scope.limit = limit;
    $scope.libraryTemp = {};
    $scope.totalItemsTemp = {};
    $scope.searchValue = "";
    $scope.totalItems = 0;
    var page = 1;
    var searchValue = '';
    getCats(page, searchValue, limit);
    $scope.pageChanged = function (newPage) {
        getCats(newPage, '', limit);
    };
    
    function getCats(page, searchValue, limit)
    {
        var postParam = {
            page: page,
            limit: limit,
            searchValue: searchValue
        }
        dataFactory.httpRequest('/items/categorys', 'POST', '', postParam).then(function (response) {
            $scope.data = response.dataList;
            $scope.totalItems = response.total;
            $scope.pageNumber = postParam.page;
        });
    }
 


    $scope.validationOptions = {
        rules: {
            name: {
                required: true,
                minlength: 5
            }
        },
        messages: {
            name: {
                required: "Please enter category",
                minlength: "This input must have a minimum length of 6 characters"
            }
        }
    }
    $scope.addEdit = function (form)
    {
        if (form.validate())
        {
            var postData = $scope.form;

            dataFactory.httpRequest('/items/addEditCategory', 'POST', {}, postData).then(function (data) {
                getCats(1, '', $scope.limit);
                $(".modal").modal("hide");
            });

        }
    }

    $scope.edit = function (id)
    {
        var postData = {'id': id};
        console.log(postData);
        dataFactory.httpRequest('/items/getCat', 'POST', {}, postData).then(function (data) {
            $scope.form = data;
        });
    }
    $scope.delete = function (id)
    {
        var postData = {'id': id};
        console.log(postData);
        var result = confirm("Are you sure delete this item?");
        if (result) {
            dataFactory.httpRequest('/items/deleteCat', 'POST', {}, postData).then(function (data) {
                getCats(1, '', $scope.limit);

            });
        }
    }
 
    $scope.searchDB = function()
    {
        getCats(1,$scope.searchValue,$scope.limit);
    }
    $scope.modalData={};
  $scope.animationsEnabled = true;

  $scope.open = function (catId,size) {
      
    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      ariaLabelledBy: 'modal-title',
      ariaDescribedBy: 'modal-body',
      templateUrl: 'templates/subCategoryModal.html',
      controller: 'ModalInstanceCtrl',
      controllerAs: '$scope',
      size: size,
      resolve: {
        modalData: function () {
            $scope.modalData.type='subcategory';
            $scope.modalData.catId=catId;
          return $scope.modalData;
        }
      }
    });


  };
});


