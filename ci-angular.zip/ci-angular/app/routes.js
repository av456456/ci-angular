var app = angular.module('main-App', ['ngRoute', 'angularUtils.directives.dirPagination','ngValidate','ui.bootstrap']);

app.config(['$routeProvider',
    function ($routeProvider) {
        $routeProvider.
                when('/', {
                    templateUrl: 'templates/index.html',
                    controller: 'FrontController',
                    loginAccess: true
                }).when('/login', {
                    templateUrl: 'templates/login.html',
                    controller: 'LoginController',
                    loginAccess: false
                }).
                        otherwise({
            redirectTo: '/'
        });
    }]).run(function ($rootScope, $location, dataFactory) {
    $rootScope.$on("$routeChangeStart", function (event, next, current) {
        $rootScope.authenticated = false;
        var nextUrl = next.$$route.originalPath;
        var log = false;
        console.log(next);
//        dataFactory.httpRequest('/home/checkLogin').then(function (results) {
//            var responseData = results.responseData;
//            if (results.status == 200 && responseData.login == true) {
//                $rootScope.authenticated = true;
//                $rootScope.loginData = responseData;
//                log = true;
//            }
//            if (log == true)
//            {
//                if (next.loginAccess == false)
//                {
//                    $location.path('/');
//                }
//            } else {
//                $location.path('/home/login');
//            }
//        });
    });
});