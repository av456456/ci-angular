<html lang="en">
    <head>
        <title>Admin Panel</title>

        <!-- Fonts -->
        <link href='//fonts.googleapis.com/css?family=Roboto:400,300' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>">

        <script src="<?php echo base_url('assets/js/jquery/jquery.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/jquery/bootstrap.min.js')?>"></script>

        <!-- Angular JS -->
        <script src="<?php echo base_url('assets/js/angular.min.js')?>"></script>
        <script src="<?php echo base_url('assets/js/angular-route.min.js')?>"></script>
        
        <script src="<?php echo base_url('assets/js/ui-bootstrap-tpls-2.1.3.js')?>"></script>
        <script src="<?php echo base_url('assets/js/jquery/jquery.validate.js')?>"></script>
        <script src="<?php echo base_url('assets/js/angular-validate.js')?>"></script>
        <!-- MY App -->
        <script src="app/packages/dirPagination.js"></script>
        <script src="app/routes.js"></script>
        <script src="app/services/myServices.js"></script>
         <script src="app/directive.js"></script>
        <script src="app/helper/myHelper.js"></script>

        <!-- App Controller -->
        <script src="app/controllers/LoginController.js"></script>
        <script src="app/controllers/AdminController.js"></script>
        <script src="app/controllers/ItemController.js"></script>
        <script src="app/controllers/CatController.js"></script>
         <script src="app/controllers/ModalInstanceCtrl.js"></script>
<script src="app/controllers/ProductController.js"></script>
    </head>
    <body ng-app="main-App">
        <nav class="navbar navbar-default">
            <div class="container-fluid">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#">Admin Panel</a>
                </div>

                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul class="nav navbar-nav">
                        <li><a href="#/" ng-show="authenticated">Home</a></li>
                        <li><a href="#/login" ng-hide="authenticated">Login</a></li>
                        <li><a href="#/items" ng-show="authenticated">Item</a></li>
                        <li><a href="#/categorys" ng-show="authenticated">Category</a></li>
                         <li><a href="#/products" ng-show="authenticated">Products</a></li>
                        <li><a href="" ng-show="authenticated" ng-controller="AdminController" ng-click="logOut()">Logout</a></li>
                    </ul>
                </div>
            </div>
        </nav>

        <div class="container">
            <ng-view></ng-view>
        </div>

    </body>
</html>
