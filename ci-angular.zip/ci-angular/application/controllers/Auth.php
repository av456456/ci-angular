<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function index() {

        if (!empty($this->input->get("search"))) {
            $this->db->like('title', $this->input->get("search"));
            $this->db->or_like('description', $this->input->get("search"));
        }

        $this->db->limit(5, ($this->input->get("page", 1) - 1) * 5);
        $query = $this->db->get("items");

        $data['data'] = $query->result();
        $data['total'] = $this->db->count_all("items");

        echo json_encode($data);
    }

    public function login() {
        $_POST = getJsonParam();
        extract($_POST);
        $respData=$data = array();
        $status = 200;
        $message = "";
        $rules['username'] = array('username', 'required');
        $rules['password'] = array('password', 'required');
        $this->Commonmodel->setFormsValidation($rules);
        if ($this->form_validation->run() == TRUE) {
            $password = md5($password);
            $dbAdmin = $this->Commonmodel->get_single_data('admin', "username = '$username' and password = '$password'", "*");
            if (count($dbAdmin) > 0) {
                $this->session->set_userdata('loginData', $dbAdmin);
                $data['loginData'] = $dbAdmin;
                $data['auth'] = true;
            } else {
                $status = 201;
                $message = "Invalid username/password";
            }
        } else {
            $status = 201;
            $message = strip_tags(validation_errors());
        }
        $respData['status'] = $status;
        $respData['message'] = $message;
        $respData['responseData'] = $data;
        echo json_encode($respData);
    }

    public function checkLogin() {
       $respData=$data = array();
        $status = 200;
        $message = "";
      $respData['login']=false;
        if($this->session->userdata('loginData'))
       {
                $respData['login']=true;
                $respData['loginData']=$this->session->userdata('loginData');
        } else {
            $status = 201;
            $message = "";
        }
        $data['status'] = $status;
        $data['message'] = $message;
        $data['responseData'] = $respData;
        echo json_encode($data);
    }

    public function update($id) {
        $this->load->database();
        $_POST = json_decode(file_get_contents('php://input'), true);

        $insert = $this->input->post();
        $this->db->where('id', $id);
        $this->db->update('items', $insert);

        $q = $this->db->get_where('items', array('id' => $id));
        echo json_encode($q->row());
    }

    public function logout() {
        $data=array('status'=>200,'message'=>'');
        if($this->session->userdata('loginData'))
        {
            $this->session->unset_userdata('loginData');
            $data['message']="Logout successfully";
        }
        echo json_encode($data);
    }

}
