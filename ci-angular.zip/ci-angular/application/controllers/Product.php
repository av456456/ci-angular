<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function index() {
        $_POST = getJsonParam();
        $table = "product";
        $data = array();
        extract($this->input->post());
        $page = isset($page) ? $page : 1;
        $search = isset($searchValue) ? $searchValue : '';
        $where = "catId = '0'";
        $where.=(!empty($search)) ? " and (name = '$search' or name like '%$search%')" : "";
        $start = ($page - 1) * $limit;
        $lim = array('start' => $start, 'limit' => $limit);
        $fields = "*";
        $dbCats = $this->Commonmodel->get_data($table, $where, $fields, "", $lim);
        $data['total'] = $total = $this->Commonmodel->get_count($table, $where);
        $data['q'] = $this->db->last_query();
        $data['dataList'] = $dbCats;
        echo json_encode($data);
    }

    public function getProduct() {
        $_POST = getJsonParam();
        $table = "product";
        $data = array();
        extract($this->input->post());
        $where = "id = '$id'";
        $fields = "*";
        $dbCats = $this->Commonmodel->get_single_data($table, $where, $fields);
        $data = $dbCats;
        echo json_encode($data);
    }
    
    
    public function getCategory() {
        $_POST = getJsonParam();
        $table = "category";
        $data = array();
        extract($this->input->post());
        $where = "catId = '0'";
        $fields = "*";
        $dbCats = $this->Commonmodel->get_data($table, $where, $fields);
        $data = $dbCats;
        echo json_encode($data);
    }
    
    public function getSubCategory() {
        $_POST = getJsonParam();
        $table = "category";
        $data = array();
        extract($this->input->post());
        $where = "catId = '$catId'";
        $fields = "*";
        $dbCats = $this->Commonmodel->get_data($table, $where, $fields);
        $data = $dbCats;
        echo json_encode($data);
    }

    public function deleteProduct() {
        $_POST = getJsonParam();
        $table = "product";
        $data = array();
        extract($this->input->post());
        $where = "id = '$id'";
        $this->Commonmodel->delete_data($table, $where);
        echo json_encode($data);
    }

    public function addEditProduct() {
        $table = 'product';
        $data = array('status' => 200, 'message' => '', 'data' => array());
        $data['postData']= $info = $_POST;
        $data['files']=$_FILES;
        extract($this->input->post());
        $rules['name'] = array('name', 'required');
        $rules['catId'] = array('category', 'required');
        $rules['subCatId'] = array('sub category', 'required');
        $this->Commonmodel->setFormsValidation($rules);
        if ($this->form_validation->run() == true) {
            if (empty($id)) {
                $this->Commonmodel->save_data($table, $info);
                $msg = "Record successfully saved";
            } else {
                $this->Commonmodel->update_data($table, $info, "id = '$id'");
                $msg = "Record successfully updated";
            }

            $data['message'] = $msg;
        } else {
            $data['status'] = 201;
            $data['message'] = strip_tags(validation_errors());
        }
        echo json_encode($data);
    }

}
