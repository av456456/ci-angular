<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Items extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function index() {
        $this->load->database();

        if (!empty($this->input->get("search"))) {
            $this->db->like('title', $this->input->get("search"));
            $this->db->or_like('description', $this->input->get("search"));
        }

        $this->db->limit(2, ($this->input->get("page", 1) - 1) * 2);
        $query = $this->db->get("items");

        $data['data'] = $query->result();
        $data['total'] = $this->db->count_all("items");

        echo json_encode($data);
    }

    public function store() {
        $this->load->database();
        $_POST = json_decode(file_get_contents('php://input'), true);
        $insert = $this->input->post();
        $this->db->insert('items', $insert);

        $id = $this->db->insert_id();
        $q = $this->db->get_where('items', array('id' => $id));
        echo json_encode($q->row());
    }

    public function edit($id) {
        $this->load->database();

        $q = $this->db->get_where('items', array('id' => $id));
        echo json_encode($q->row());
    }

    public function update($id) {
        $this->load->database();
        $_POST = json_decode(file_get_contents('php://input'), true);

        $insert = $this->input->post();
        $this->db->where('id', $id);
        $this->db->update('items', $insert);

        $q = $this->db->get_where('items', array('id' => $id));
        echo json_encode($q->row());
    }

    public function delete($id) {
        $this->load->database();
        $this->db->where('id', $id);
        $this->db->delete('items');
        echo json_encode(['success' => true]);
    }

    public function categorys() {
        $_POST=  getJsonParam();
        $table="category";
        $data=array();
        extract($this->input->post());
        $page=isset($page)?$page:1;
        $search=isset($searchValue)?$searchValue:'';
        $where="catId = '0'";
        $where.=(!empty($search))?" and (name = '$search' or name like '%$search%')":"";
        $start=($page-1)*$limit;
        $lim=array('start'=>$start,'limit'=>$limit);
        $fields="*";
        $dbCats=$this->Commonmodel->get_data($table,$where,$fields,"",$lim);
        $data['total']=$total=$this->Commonmodel->get_count($table,$where);
        $data['q']=$this->db->last_query();
        $data['dataList']=$dbCats;
        echo json_encode($data);
    }
    
    
    public function getCat() {
        $_POST=  getJsonParam();
        $table="category";
        $data=array();
        extract($this->input->post());
        $where="id = '$id'";
        $fields="*";
        $dbCats=$this->Commonmodel->get_single_data($table,$where,$fields);
        $data=$dbCats;
        echo json_encode($data);
    }
    
      public function deleteCat() {
        $_POST=  getJsonParam();
        $table="category";
        $data=array();
        extract($this->input->post());
        $where="id = '$id'";
        $this->Commonmodel->delete_data($table,$where);
        echo json_encode($data);
    }
    
    public function addEditCategory()
    {
        $table='category';
        $data=array('status'=>200,'message'=>'','data'=>array());
        $info=$_POST=  getJsonParam();
        extract($this->input->post());
        $rules['name']=array('name','required');
        $this->Commonmodel->setFormsValidation($rules);
        if($this->form_validation->run() == true)
        {
            if(empty($id))
            {
                $this->Commonmodel->save_data($table,$info);
                $msg="Record successfully saved";
            }else{
                $this->Commonmodel->update_data($table,$info,"id = '$id'");
                $msg="Record successfully updated";
            }
            
            $data['message']=$msg;
        }else{
            $data['status']=201;
            $data['message']=  strip_tags(validation_errors());
        }
        echo json_encode($data);
    }
    

     public function subCategorys() {
        $_POST=  getJsonParam();
        $table="category";
        $data=array();
        extract($this->input->post());
        $page=isset($page)?$page:1;
        $search=isset($search)?$search:'';
        $where="catId = '$catId'";
        $where.=(!empty($search))?" and name = '$search' or name like '%$search%'":"";
        $start=($page-1)*$limit;
        $lim=array('start'=>$start,'limit'=>$limit);
        $fields="*";
        $dbCats=$this->Commonmodel->get_data($table,$where,$fields,"",$lim);
        $data['total']=$total=$this->Commonmodel->get_count($table,$where);
        $data['dataList']=$dbCats;
        echo json_encode($data);
    }
    
    
    public function getSubCat() {
        $_POST=  getJsonParam();
        $table="category";
        $data=array();
        extract($this->input->post());
        $where = "id = '$id'";
        $fields="*";
        $dbCats=$this->Commonmodel->get_single_data($table,$where,$fields);
       $data=$dbCats;
        echo json_encode($data);
    }
    
      public function deleteSubCat() {
        $_POST=  getJsonParam();
        $table="category";
        $data=array();
        extract($this->input->post());
        $where="id = '$id'";
        $this->Commonmodel->delete_data($table,$where);
        echo json_encode($data);
    }
    
    public function addEditSubCategory()
    {
        $table='category';
        $data=array('status'=>200,'message'=>'','data'=>array());
        $info=$_POST=  getJsonParam();
        extract($this->input->post());
        $rules['name']=array('name','required');
         $rules['catId']=array('category id','required');
        $this->Commonmodel->setFormsValidation($rules);
        if($this->form_validation->run() == true)
        {
            if(empty($id))
            {
                $this->Commonmodel->save_data($table,$info);
                $msg="Record successfully saved";
            }else{
                $this->Commonmodel->update_data($table,$info,"id = '$id'");
                $msg="Record successfully updated";
            }
            
            $data['message']=$msg;
        }else{
            $data['status']=201;
            $data['message']=  strip_tags(validation_errors());
        }
        echo json_encode($data);
    }
    

    
        }
