require('./buttons');

var MODULE_NAME = 'ui.bootstrap.module.buttons';

angular.module(MODULE_NAME, ['ui.bootstrap.buttons']);

module.exports = MODULE_NAME;
